import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from math import sqrt

# Charger les données historiques
historical_path = 'precipitations_combined.csv'
data = pd.read_csv(historical_path)


# Afficher les colonnes pour vérifier la structure
#print("Colonnes du dataset historique :", data.columns)

# Harmoniser les colonnes avec l'API Meteostat
column_mapping = {
    'temp': 'tavg',  # temp = température moyenne
    'dwpt': 'tmin',  # dwpt = point de rosée (approximation pour tmin)
    'rhum': 'tmax',  # rhum = humidité relative (approximation pour tmax)
}
data.rename(columns=column_mapping, inplace=True)

# Remplacer les valeurs manquantes
for col in ['prcp', 'snow', 'wdir', 'wspd', 'wpgt', 'pres', 'tsun']:
    if col in data.columns:
        data[col] = data[col].fillna(0)

#print("Valeurs manquantes après nettoyage :\n", data.isnull().sum())

# Séparer les features et la cible
X = data[['tavg', 'tmin', 'tmax', 'snow', 'wdir', 'wspd', 'wpgt', 'pres', 'tsun']]
y = data['prcp']

# Entraîner le modèle
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X, y)

# Évaluer le modèle
y_pred = model.predict(X)
rmse = sqrt(mean_squared_error(y, y_pred))
mae = mean_absolute_error(y, y_pred)
r2 = r2_score(y, y_pred)
print("R² (coefficient de détermination) :", r2)
print("RMSE :", rmse)
print("MAE :", mae)

# Charger les données en temps réel
realtime_path = 'precipitations_tunis_realtime.csv'
data_realtime = pd.read_csv(realtime_path)

# Afficher les colonnes pour vérifier
#print("Colonnes du dataset en temps réel :", data_realtime.columns)

# Renommer et harmoniser les colonnes
if 'temp' in data_realtime.columns:
    data_realtime.rename(columns=column_mapping, inplace=True)

# Ajouter les colonnes manquantes si absentes
def add_missing_columns(df, reference_df):
    missing_cols = set(reference_df.columns) - set(df.columns)
    for col in missing_cols:
        df[col] = 0
    return df

data_realtime = add_missing_columns(data_realtime, X)

# Réordonner les colonnes
data_realtime = data_realtime[X.columns]

# Remplacer les NaN restants
for col in X.columns:
    data_realtime[col] = data_realtime[col].fillna(data[col].median())

# Faire une prédiction
predictions = model.predict(data_realtime)
print("Prédictions des précipitations :", predictions)

import pickle
with open('model.pkl', 'wb') as f:
    pickle.dump(model, f)