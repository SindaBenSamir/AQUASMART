# main_predictor.py

import subprocess

def run_prediction_pipeline():
    print(">> Récupération des données temps réel...")
    subprocess.run(["python", "temps_réel.py"])

    print(">> Prédiction journalière...")
    subprocess.run(["python", "journaliere.py"])

    print(">> Prédiction saisonnière...")
    subprocess.run(["python", "prediction_saiso.py"])
    
    print(">> Démarrage de l'API FastAPI...")
    subprocess.run(["uvicorn", "season_api:app", "--reload"])

    print(">> Pipeline terminé.")
    
if __name__ == "__main__":
    run_prediction_pipeline()
