import requests
from datetime import datetime
import mysql.connector

# Connexion à la base de données MySQL
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Sinda070203*",  # Ton mot de passe ici
    database="aquasmart_db"
)

cursor = db.cursor()

# URL de l'API pour obtenir la prédiction à partir du CSV en temps réel
url = "http://127.0.0.1:8000/predict_from_csv"

# Appeler l'API
response = requests.get(url)

if response.status_code == 200:
    data = response.json()
    predictions = data['predictions']  # Extraire la liste de prédictions
    
    if predictions:
        prediction = predictions[0]  # Prendre la première prédiction de la liste
        
        # Supprimer les anciennes données
        delete_sql = "DELETE FROM predictions_journalieres"
        cursor.execute(delete_sql)
        db.commit()
        print("Anciennes prédictions supprimées ✅")

        # Insérer la nouvelle prédiction
        sql = "INSERT INTO predictions_journalieres (date_prediction, Precipitation_Prevue) VALUES (%s, %s)"
        values = (datetime.now().date(), prediction)
        cursor.execute(sql, values)
        db.commit()
        print(f"Nouvelle prédiction '{prediction}' insérée ✅")
    else:
        print("Pas de prédiction disponible dans le CSV.")
else:
    print("Erreur lors de l'appel API :", response.text)

cursor.close()
db.close()
