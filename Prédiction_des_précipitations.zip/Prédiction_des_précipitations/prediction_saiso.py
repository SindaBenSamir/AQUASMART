import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.utils import to_categorical
import matplotlib.pyplot as plt

# 1. Charger les données
df = pd.read_csv('precipitations_tunis.csv')  # Remplace par le nom de ton fichier
df['time'] = pd.to_datetime(df['time'])

# 2. Remplir les valeurs manquantes
df.fillna(0, inplace=True)
 
# 3. Extraire les colonnes numériques
features = ['tavg', 'tmin', 'tmax', 'prcp', 'snow', 'wdir', 'wspd', 'wpgt', 'pres', 'tsun']
df_features = df[features].copy()

# 4. Normaliser les données
scaler = StandardScaler()
df_scaled = scaler.fit_transform(df_features)
df_scaled = pd.DataFrame(df_scaled, columns=features)
df_scaled['time'] = df['time']

# 5. Créer des moyennes saisonnières
df_scaled['year'] = df['time'].dt.year
df_scaled['month'] = df['time'].dt.month
df_scaled['season'] = df_scaled['month'] % 12 // 3 + 1  # 1=winter, 2=spring...

seasonal = df_scaled.groupby(['year', 'season'])[features].mean().reset_index()

# 6. Clustering des saisons
X_cluster = seasonal[features]
kmeans = KMeans(n_clusters=3, random_state=0)
seasonal['label'] = kmeans.fit_predict(X_cluster)

# Convertir les colonnes pour éviter le mismatch de type
df_scaled['year'] = df_scaled['year'].astype(np.int64)
df_scaled['season'] = df_scaled['season'].astype(np.int64)
seasonal['year'] = seasonal['year'].astype(np.int64)
seasonal['season'] = seasonal['season'].astype(np.int64)


# 7. Assigner les labels saisonniers à tous les jours du dataset
df_labeled = df_scaled.merge(seasonal[['year', 'season', 'label']], on=['year', 'season'], how='left')

# 8. Créer les séquences (60 jours) et labels associés
sequence_length = 60
X_seq, y_seq = [], []

data_array = df_labeled[features].values
labels_array = df_labeled['label'].values

for i in range(len(data_array) - sequence_length):
    X_seq.append(data_array[i:i+sequence_length])
    y_seq.append(labels_array[i + sequence_length])

X_seq = np.array(X_seq)
y_seq = np.array(y_seq)

# 9. Séparer en train/test
X_train, X_test, y_train, y_test = train_test_split(X_seq, y_seq, test_size=0.2, random_state=42)

# 10. Construire le modèle LSTM
model = Sequential([
    LSTM(64, input_shape=(sequence_length, len(features))),
    Dense(32, activation='relu'),
    Dense(3, activation='softmax')
])
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# 11. Entraînement
history = model.fit(X_train, y_train, epochs=20, batch_size=32, validation_split=0.1)

# 12. Évaluation
loss, acc = model.evaluate(X_test, y_test)
print(f"Accuracy: {acc:.2f}")

# 13. Courbe d’apprentissage
plt.plot(history.history['accuracy'], label='train acc')
plt.plot(history.history['val_accuracy'], label='val acc')
plt.legend()
plt.title("Évolution de la précision")
plt.show()

# 14. Préparer la séquence pour la prochaine période (60 derniers jours)
last_60_days = df_scaled[features].iloc[-60:].values  # Prendre les 60 derniers jours
last_60_days = last_60_days.reshape((1, 60, len(features)))  # Reshape pour correspondre à la forme (1, 60, features)

# 15. Faire la prédiction pour la prochaine période
predicted_class = model.predict(last_60_days)
predicted_label = np.argmax(predicted_class, axis=1)  # Trouver la classe avec la probabilité la plus élevée

# Afficher la classe prédite (0=seche, 1=moyenne, 2=pluvieuse)
classes = ['seche', 'moyenne', 'pluvieuse']
print(f"La prochaine période est : {classes[predicted_label[0]]}")


