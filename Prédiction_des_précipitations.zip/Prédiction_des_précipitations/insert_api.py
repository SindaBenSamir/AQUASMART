import requests
from datetime import datetime
import mysql.connector

# Connexion à la base de données
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Sinda070203*",
    database="aquasmart_db"
)

cursor = db.cursor()

# Appeler l'API
url = "http://127.0.0.1:8000/prediction_saisonniere"  # remplace par ton URL API
response = requests.get(url)

if response.status_code == 200:
    data = response.json()
    prediction = data['prediction']
    
    # Supprimer toutes les anciennes données dans la table
    delete_sql = "DELETE FROM prediction_saisonniere"
    cursor.execute(delete_sql)
    db.commit()
    print("Anciennes données supprimées ✅")

    # Insérer la nouvelle prédiction dans la base de données
    sql = "INSERT INTO prediction_saisonniere (date_prediction, prediction) VALUES (%s, %s)"
    values = (datetime.now().date(), prediction)
    cursor.execute(sql, values)
    db.commit()

    print(f"Prédiction '{prediction}' insérée ✅")

else:
    print("Erreur appel API :", response.text)

cursor.close()
db.close()
