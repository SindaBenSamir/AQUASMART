import pandas as pd
import numpy as np
from fastapi import FastAPI
from sklearn.ensemble import RandomForestRegressor
import pickle

# Charger le modèle déjà entraîné
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)

# Créer l'application FastAPI
app = FastAPI()

# Fonction pour prédire les précipitations via une requête GET
@app.get("/predict")
def predict_precipitation(
    tavg: float, 
    tmin: float, 
    tmax: float, 
    snow: float, 
    wdir: float, 
    wspd: float, 
    wpgt: float, 
    pres: float, 
    tsun: float
):
    # Créer un DataFrame avec les données reçues depuis la requête GET
    data = pd.DataFrame([{
        'tavg': tavg,
        'tmin': tmin,
        'tmax': tmax,
        'snow': snow,
        'wdir': wdir,
        'wspd': wspd,
        'wpgt': wpgt,
        'pres': pres,
        'tsun': tsun,
    }])
    
    # Utiliser le modèle pour prédire
    prediction = model.predict(data)
    
    # Retourner la prédiction sous forme de JSON
    return {"prediction": prediction[0]}


# Nouvelle route pour traiter les données réelles depuis le CSV
@app.get("/predict_from_csv")
def predict_from_csv():
    # Lire le fichier CSV avec les données réelles
    realtime_path = 'precipitations_tunis_realtime.csv'
    data_realtime = pd.read_csv(realtime_path)

    # Harmoniser les colonnes du CSV avec les attentes du modèle
    column_mapping = {
        'temp': 'tavg',
        'dwpt': 'tmin',
        'rhum': 'tmax',
    }
    data_realtime.rename(columns=column_mapping, inplace=True)

    # Remplacer les valeurs manquantes
    for col in ['prcp', 'snow', 'wdir', 'wspd', 'wpgt', 'pres', 'tsun']:
        if col in data_realtime.columns:
            data_realtime[col] = data_realtime[col].fillna(0)

    # Sélectionner les colonnes de caractéristiques attendues par le modèle
    X = data_realtime[['tavg', 'tmin', 'tmax', 'snow', 'wdir', 'wspd', 'wpgt', 'pres', 'tsun']]

    # Remplacer les NaN restants
    for col in X.columns:
        X[col] = X[col].fillna(data_realtime[col].median())

    # Prédire les précipitations
    predictions = model.predict(X)

    # Retourner les prédictions sous forme de JSON
    return {"predictions": predictions.tolist()}

