import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import load_model
from sklearn.preprocessing import StandardScaler
import joblib

# 🔹 Charger le modèle
model = load_model("autoencoder_model.h5", compile=False)

# 🔹 Charger les données
df_test = pd.read_csv("C:/Users/user/Downloads/test_data_anomalies.csv")
df_test['Date'] = df_test['Date'].str.strip()

df_test['Date'] = pd.to_datetime(df_test['Date'])
df_test.set_index('Date', inplace=True)

# 🔹 Ajouter colonnes temporelles
df_test["day_of_week"] = df_test.index.dayofweek
df_test["month"] = df_test.index.month
df_test["hour"] = df_test.index.hour
df_test['season'] = ((df_test["month"] % 12 + 3) // 3) % 4

# 🔹 Colonnes utilisées
features = ['Potability', 'day_of_week', 'month', 'hour', 'season']
df_test = df_test.interpolate().dropna()

# 🔹 Normalisation
scaler = StandardScaler()
scaled_data = scaler.fit_transform(df_test[features])

# 🔹 Séquençage
SEQ_LENGTH = 30
def create_sequences(data, seq_length):
    sequences = []
    for i in range(len(data) - seq_length + 1):
        sequences.append(data[i:i + seq_length])
    return np.array(sequences)

X_test = create_sequences(scaled_data, SEQ_LENGTH)

# 🔹 Vérification des valeurs
print(f"Forme de X_test : {X_test.shape}")
if np.any(np.isnan(X_test)) or np.any(np.isinf(X_test)):
    print("🚨 Des valeurs NaN ou infinies sont présentes dans X_test")
    X_test = np.nan_to_num(X_test, nan=0.0, posinf=0.0, neginf=0.0)
else:
    print("✅ Les données sont valides.")

try:
    # 🔹 Prédictions autoencoder
    X_pred = model.predict(X_test)
    reconstruction_errors = np.mean(np.square(X_pred - X_test), axis=(1, 2))

    # 🔹 Affichage des erreurs
    plt.figure(figsize=(12, 4))
    plt.plot(reconstruction_errors, label="Erreur de reconstruction")
    plt.axhline(np.percentile(reconstruction_errors, 95), color='r', linestyle='--', label="Seuil 95e percentile")
    plt.title("Erreurs de reconstruction")
    plt.xlabel("Index de séquence")
    plt.ylabel("Erreur")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    # 🔹 DATES alignées avec les séquences
    sequence_dates = df_test.index[SEQ_LENGTH - 1:]

    # 🔹 Méthode 1 : Isolation Forest
    iso_forest = joblib.load("isoforest_model.pkl")
    iso_labels = iso_forest.predict(reconstruction_errors.reshape(-1, 1))
    anomalies_iso = iso_labels == -1

    print("🚨 Anomalies détectées avec Isolation Forest :")
    any_iso = False
    for i, is_anomaly in enumerate(anomalies_iso):
        if is_anomaly:
            print(f"➡️  IF : Anomalie détectée à la date : {sequence_dates[i]}")
            any_iso = True
    if not any_iso:
        print("✅ Aucune anomalie détectée avec Isolation Forest.")
    erreurs = reconstruction_errors
        # On suppose que reconstruction_errors est une Series avec des timestamps en index
    

    mean = np.mean(reconstruction_errors)
    std = np.std(reconstruction_errors)
    seuil = mean + 2 * std  # Seuil simple (moyenne + 2 écart-types)

    # Anomalies selon le seuil
    anomalies_manual = reconstruction_errors > seuil
    print("\n🚨 Anomalies détectées avec seuil manuel (95e percentile) :")
    any_manual = False
    for i, is_anomaly in enumerate(anomalies_manual):
        if is_anomaly:
            print(f"➡️  Seuil : Anomalie détectée à la date : {sequence_dates[i]}")
            any_manual = True
    if not any_manual:
        print("✅ Aucune anomalie détectée avec la méthode seuil.")

    # 🔹 Affichage combiné des anomalies (IF et seuil) sur les erreurs de reconstruction
    plt.figure(figsize=(15, 5))
    plt.plot(sequence_dates, reconstruction_errors, label="Erreur de reconstruction", color='lightgray')

    # Anomalies - Isolation Forest
    plt.scatter(sequence_dates[anomalies_iso], reconstruction_errors[anomalies_iso], 
                color='red', label="Anomalies Isolation Forest", marker='x', s=60)

    # Anomalies - Seuil manuel
    plt.scatter(sequence_dates[anomalies_manual], reconstruction_errors[anomalies_manual], 
                color='blue', label="Anomalies Seuil manuel", marker='o', s=60, facecolors='none')

    # Seuil affiché
    plt.axhline(seuil, color='black', linestyle='--', label=f'Seuil manuel: {seuil:.4f}')

    # Final touches
    plt.title("Détection d'anomalies : Autoencoder vs Isolation Forest")
    plt.xlabel("Date")
    plt.ylabel("Erreur de reconstruction")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()
    

except Exception as e:
    print(f"❌ Une erreur est survenue pendant la prédiction : {e}")
