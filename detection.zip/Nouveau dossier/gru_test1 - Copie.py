import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, GRU, RepeatVector, TimeDistributed, Dense
from tensorflow.keras.callbacks import EarlyStopping
import joblib
import seaborn as sns

# 🔹 Chargement des données
df = pd.read_csv("C:/Users/user/Downloads/water_potability_with_dates.csv")
df['Date'] = pd.to_datetime(df['Date'])
df.set_index('Date', inplace=True)

# 🔹 Variables temporelles
df["day_of_week"] = df.index.dayofweek
df["month"] = df.index.month
df["hour"] = df.index.hour
df["season"] = ((df["month"] % 12 + 3) // 3) % 4

# 🔹 Imputation & normalisation
df = df.interpolate(method='time').dropna()
scaler = StandardScaler()
scaled_data = scaler.fit_transform(df[['Potability', 'day_of_week', 'month', 'hour', 'season']])

# 🔹 Création des séquences
SEQ_LENGTH = 30
def create_sequences(data, seq_length):
    sequences = []
    for i in range(len(data) - seq_length):
        sequences.append(data[i:i + seq_length])
    return np.array(sequences)

X = create_sequences(scaled_data, SEQ_LENGTH)

# 🔹 Restreindre l’entraînement aux données normales
train_size = int(len(X) * 0.7)  # Utilisation de 70% des données pour l'entraînement
X_train = X[:train_size]
X_val = X[train_size:]

# 🔹 Architecture du GRU autoencodeur
input_layer = Input(shape=(SEQ_LENGTH, X.shape[2]))
encoded = GRU(64, return_sequences=True, dropout=0.3, recurrent_dropout=0.2)(input_layer)
encoded = GRU(32, return_sequences=False, dropout=0.3, recurrent_dropout=0.2)(encoded)
repeated = RepeatVector(SEQ_LENGTH)(encoded)
decoded = GRU(64, return_sequences=True, dropout=0.3, recurrent_dropout=0.2)(repeated)
output_layer = TimeDistributed(Dense(X.shape[2]))(decoded)

autoencoder = Model(inputs=input_layer, outputs=output_layer)
autoencoder.compile(optimizer='adam', loss='mse')

# 🔹 EarlyStopping
early_stop = EarlyStopping(monitor='val_loss', patience=30, restore_best_weights=True, mode='min', verbose=1)

# 🔹 Entraînement
history = autoencoder.fit(X_train, X_train, epochs=500, batch_size=64, validation_data=(X_val, X_val), callbacks=[early_stop], shuffle=False, verbose=1)

# 🔹 Sauvegarde du modèle
autoencoder.save("autoencoder_model.h5")
print("✅ Modèle sauvegardé sous le nom 'autoencoder_model.h5'")

# 🔹 Prédictions et erreurs de reconstruction
X_pred = autoencoder.predict(X)
reconstruction_errors = np.mean(np.square(X_pred - X), axis=(1, 2))

# 🔹 Visualiser la distribution des erreurs de reconstruction
plt.figure(figsize=(10, 5))
sns.histplot(reconstruction_errors, bins=50, kde=True, color='purple')
plt.title("Distribution des erreurs de reconstruction")
plt.xlabel("Erreur")
plt.ylabel("Fréquence")
plt.grid(True)
plt.tight_layout()
plt.show()

# 🔹 Tester un seuil statique pour la détection des anomalies
mean = np.mean(reconstruction_errors)
std = np.std(reconstruction_errors)
seuil = mean + 2 * std  # Seuil simple (moyenne + 2 écart-types)

# Anomalies selon le seuil
anomalies_stat = reconstruction_errors > seuil

# 🔹 Visualiser les erreurs de reconstruction dans le temps
plt.figure(figsize=(12, 5))
plt.plot(df.index[SEQ_LENGTH:], reconstruction_errors, label='Erreur de reconstruction')
plt.scatter(df.index[SEQ_LENGTH:][anomalies_stat], reconstruction_errors[anomalies_stat], color='red', label='Anomalies')
plt.title("Erreur de reconstruction dans le temps")
plt.xlabel("Date")
plt.ylabel("Erreur")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# 🔹 Isolation Forest sur les erreurs de reconstruction
iso_forest = IsolationForest(contamination=0.05, random_state=42)
iso_forest.fit(reconstruction_errors.reshape(-1, 1))
anomaly_labels = iso_forest.predict(reconstruction_errors.reshape(-1, 1))
# -1 = anomalie, 1 = normal
anomalies_isoforest = anomaly_labels == -1

# 🔹 Dates des anomalies détectées par Isolation Forest
anomaly_dates = df.index[SEQ_LENGTH:][anomalies_isoforest]
print("🚨 Dates des anomalies détectées par Isolation Forest :")
print(anomaly_dates)

# 🔹 Sauvegarde du modèle Isolation Forest
joblib.dump(iso_forest, "isoforest_model.pkl")
print("✅ Modèle Isolation Forest sauvegardé.")

# 🔹 Scores de performance
r2 = r2_score(X.reshape(-1, X.shape[2]), X_pred.reshape(-1, X.shape[2]))
mae = mean_absolute_error(X.reshape(-1, X.shape[2]), X_pred.reshape(-1, X.shape[2]))
rmse = np.sqrt(mean_squared_error(X.reshape(-1, X.shape[2]), X_pred.reshape(-1, X.shape[2])))

print(f"R²: {r2:.4f}, MAE: {mae:.4f}, RMSE: {rmse:.4f}")

# 🔹 Courbe de loss et val_loss pendant l'entraînement
plt.figure(figsize=(10, 5))
plt.plot(history.history['loss'], label='Train Loss', color='blue')
plt.plot(history.history['val_loss'], label='Validation Loss', color='orange')
plt.title("Courbes de Loss (Train et Validation) pendant l'Entraînement")
plt.xlabel("Époques")
plt.ylabel("Loss (MSE)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# 🔹 Affichage formaté des anomalies détectées
for date in anomaly_dates:
    print(f"Anomalie détectée à la date : {date}")
