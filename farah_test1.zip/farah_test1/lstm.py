import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from sklearn.metrics import mean_absolute_error, mean_squared_error

# Charger le fichier CSV
file_path = "C:/Users/user/Documents/Pcd/test1/usa_rain_prediction_dataset_2024_2025.csv"
df = pd.read_csv(file_path)

# Convertir la colonne 'Date' en format datetime et trier les données par date
df["Date"] = pd.to_datetime(df["Date"])
df = df.sort_values(by="Date")

# Sélectionner la colonne 'Precipitation' comme variable cible
data = df[["Precipitation"]].values

# Normaliser les données entre 0 et 1
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_data = scaler.fit_transform(data)

# Préparer les données pour LSTM
def create_sequences(data, seq_length):
    X, y = [], []
    for i in range(len(data) - seq_length):
        X.append(data[i:i + seq_length, 0])
        y.append(data[i + seq_length, 0])
    return np.array(X), np.array(y)

# Définir la longueur de la séquence (par exemple, 7 jours)
seq_length = 7
X, y = create_sequences(scaled_data, seq_length)

# Séparer les données en ensembles d'entraînement et de test (80% train, 20% test)
train_size = int(len(X) * 0.8)
X_train, X_test = X[:train_size], X[train_size:]
y_train, y_test = y[:train_size], y[train_size:]

# Redimensionner les données pour LSTM (format [samples, time steps, features])
X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))
X_test = X_test.reshape((X_test.shape[0], X_test.shape[1], 1))

# Construire le modèle LSTM
model = Sequential()
model.add(LSTM(50, return_sequences=True, input_shape=(X_train.shape[1], 1)))  # Couche LSTM avec 50 neurones
model.add(LSTM(50, return_sequences=False))  # Deuxième couche LSTM
model.add(Dense(25))  # Couche dense intermédiaire
model.add(Dense(1))  # Couche de sortie

# Compiler le modèle
model.compile(optimizer="adam", loss="mean_squared_error")

# Entraîner le modèle
model.fit(X_train, y_train, epochs=10, batch_size=32, verbose=1)

# Faire des prédictions sur les données de test
y_pred = model.predict(X_test)

# Inverser la normalisation pour obtenir les valeurs réelles
y_test_actual = scaler.inverse_transform(y_test.reshape(-1, 1))
y_pred_actual = scaler.inverse_transform(y_pred)

# Évaluer le modèle
mae = mean_absolute_error(y_test_actual, y_pred_actual)
mse = mean_squared_error(y_test_actual, y_pred_actual)
rmse = np.sqrt(mse)

# Afficher les résultats
print(f"Mean Absolute Error (MAE): {mae:.2f} mm")
print(f"Root Mean Squared Error (RMSE): {rmse:.2f} mm")

# Prédire la précipitation pour aujourd'hui
latest_data = scaled_data[-seq_length:]  # Dernières séquences disponibles
latest_data = latest_data.reshape((1, seq_length, 1))
prediction_today_scaled = model.predict(latest_data)
prediction_today = scaler.inverse_transform(prediction_today_scaled)[0][0]

print(f"Prédiction de la précipitation pour aujourd'hui: {prediction_today:.2f} mm")