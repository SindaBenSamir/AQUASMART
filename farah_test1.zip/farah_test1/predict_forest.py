import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

# Charger le fichier CSV
file_path = "C:/Users/user/Documents/Pcd/test1/usa_rain_prediction_dataset_2024_2025.csv"
df = pd.read_csv(file_path)

# Convertir la colonne 'Date' en format datetime et trier les données par date
df["Date"] = pd.to_datetime(df["Date"])
df = df.sort_values(by="Date")

# Créer des variables retardées (lag features)
lag_days = 30  # Utiliser les 7 derniers jours pour prédire aujourd'hui
for i in range(1, lag_days + 1):
    df[f"Precipitation_lag_{i}"] = df["Precipitation"].shift(i)

# Supprimer les valeurs NaN générées par le décalage
df = df.dropna()

# Définir les caractéristiques et la variable cible
target = "Precipitation"
features = [f"Precipitation_lag_{i}" for i in range(1, lag_days + 1)]

X = df[features]
y = df[target]

# Séparer les données en ensembles d'entraînement et de test (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=False)

# Entraîner un modèle RandomForestRegressor
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Prédictions
y_pred = model.predict(X_test)

# Évaluation du modèle
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = mse ** 0.5

# Prédire la précipitation d'aujourd'hui
latest_data = X.iloc[-1:].values  # Dernières valeurs disponibles
prediction_today = model.predict(latest_data)[0]

# Affichage des résultats
print(f"Mean Absolute Error (MAE): {mae:.2f} mm")
print(f"Root Mean Squared Error (RMSE): {rmse:.2f} mm")
print(f"Prédiction de la précipitation pour aujourd'hui: {prediction_today:.2f} mm")