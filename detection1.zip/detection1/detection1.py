import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.regularizers import l2
from tensorflow.keras.optimizers import Adam

# 1️⃣ Charger les données
file_path = "C:/Users/user/Downloads/BKB_WaterQualityData_2020084.csv"
df = pd.read_csv(file_path)

# Correction du nom de colonne mal encodé
df.rename(columns={"Water Temp (?C)": "Water Temp (°C)"}, inplace=True)

# Colonnes à conserver
cols_to_keep = [
    "Salinity (ppt)", "Dissolved Oxygen (mg/L)", "pH (standard units)",
    "Secchi Depth (m)", "Water Depth (m)", "Water Temp (°C)"
]

# Sélection et nettoyage des données
df_cleaned = df[cols_to_keep].copy()
df_cleaned.fillna(df_cleaned.median(), inplace=True)  # Remplacement des valeurs manquantes par la médiane

# Normalisation des données
scaler = StandardScaler()
df_scaled = pd.DataFrame(scaler.fit_transform(df_cleaned), columns=cols_to_keep)
df_scaled = df_scaled.loc[:, df_scaled.columns != "Anomaly"]

# Nombre de variables en entrée (colonnes de df_scaled)
input_dim = df_scaled.shape[1]

# Définition du modèle Autoencoder
# 2️⃣ Construction du modèle Autoencoder
# Définition du modèle Autoencoder
input_layer = Input(shape=(input_dim,))
encoded = Dense(32, activation="relu", kernel_regularizer=l2(0.01))(input_layer)
encoded = Dense(16, activation="relu", kernel_regularizer=l2(0.01))(encoded)
encoded = Dense(8, activation="relu", kernel_regularizer=l2(0.01))(encoded)
encoded = Dense(6, activation="relu", kernel_regularizer=l2(0.01))(encoded)  # Bottleneck ajusté

decoded = Dense(8, activation="relu", kernel_regularizer=l2(0.01))(encoded)
decoded = Dense(16, activation="relu", kernel_regularizer=l2(0.01))(decoded)
decoded = Dense(32, activation="relu", kernel_regularizer=l2(0.01))(decoded)
decoded = Dense(input_dim, activation="sigmoid")(decoded)

autoencoder = Model(input_layer, decoded)
autoencoder.compile(optimizer=Adam(learning_rate=0.001), loss="mse")

# Définition du callback EarlyStopping
early_stopping = EarlyStopping(
    monitor="val_loss",  # Surveiller la perte de validation
    patience=10,  # Nombre d'époques sans amélioration avant d'arrêter
    restore_best_weights=True,  # Restaurer les meilleurs poids (avant l'arrêt)
    verbose=1  # Afficher les informations pendant l'entraînement
)

# Entraînement avec early stopping
autoencoder.fit(
    df_scaled, df_scaled, 
    epochs=200, 
    batch_size=8, 
    shuffle=True, 
    validation_split=0.1,  # Séparer 20% des données pour la validation
    verbose=1, 
    callbacks=[early_stopping]  # Ajout du callback early stopping
)

# 4️⃣ Détection des anomalies
reconstructed = autoencoder.predict(df_scaled)
mse = np.mean(np.power(df_scaled - reconstructed, 2), axis=1)  # Erreur de reconstruction

# Calcul de MAE et RMSE
mae = np.mean(np.abs(df_scaled - reconstructed))  # Mean Absolute Error
rmse = np.sqrt(np.mean(np.power(df_scaled - reconstructed, 2)))  # Root Mean Squared Error

threshold = np.percentile(mse, 95)  # Seuil : 95e percentile
anomalies = mse > threshold

df_anomalies = df_cleaned.copy()  # Crée un dataframe pour stocker les anomalies
df_anomalies["Anomaly"] = anomalies  # Ajoute la colonne Anomaly ici, PAS dans df_scaled


 # Vérification des formes des données
print(f"Shape of df_scaled: {df_scaled.shape}")
print(f"Shape of reconstructed: {reconstructed.shape}")

# Si les dimensions correspondent, calcul du R²
if df_scaled.shape == reconstructed.shape:
    r2 = r2_score(df_scaled, reconstructed)
    print(f"R²: {r2:.2f}")
else:
    print("Les dimensions des données réelles et reconstruites ne correspondent pas.")


# 5️⃣ Evaluation des anomalies en nombre

num_anomalies = np.sum(anomalies)
print(f"Nombre d'anomalies détectées : {num_anomalies}")
print(f"Mean Absolute Error (MAE): {mae:.2f}")  # Afficher MAE
print(f"Root Mean Squared Error (RMSE): {rmse:.2f}")  # Afficher RMSE

print(df_scaled.columns)

print(df_scaled.head())  # Affiche les 5 premières lignes du dataset

print(df_scaled.info())  # Vérifie les types de données et la présence de NaN

# Afficher les anomalies détectées
df_anomalies = df_cleaned[anomalies]
print(f"Exemples d'anomalies détectées :\n{df_anomalies.head()}")
